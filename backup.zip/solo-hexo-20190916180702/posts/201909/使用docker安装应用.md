title: 使用docker安装应用
date: '2019-09-12 17:38:09'
updated: '2019-09-12 17:38:09'
tags: [Note]
permalink: /articles/2019/09/12/1568281089377.html
---
# 安装mysql

```
# 安装mysql:5.7,直接docker run 他会自动去官方镜想下载
# MYSQL_ROOT_PASSWORD=你的数据库密码
docker run --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=123456 -d mysql:5.7

# docker安装的mysql默认允许远程连接，可以使用Navicat等软件连接数据库
# 进入容器mysql
docker exec -it mysql bash

# 进入数据库 p后面跟你的密码
mysql -uroot -p123456

# 创建数据库(数据库名:solo;字符集utf8mb4;排序规则utf8mb4_general_ci)
create database solo DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
# 出现Query OK, 1 row affected (0.00 sec)表示成功
#退出数据库
exit
#退出容器
exit
```



# 安装nginx

安装 nginx 前，我们现在本地建立几个文件，用于存放 nginx 的配置文件等

```
# 切换到服务器根目录
cd /
# 创建主目录
mkdir soft
# 创建文件
mkdir soft/nginx soft/nginx/conf soft/nginx/logs soft/nginx/www soft/nginx/ssl
```

上面的`soft`可以换成自己喜欢的名字

- `soft/nginx` 用于存放 Docker 下 nginx 自定义文件
- ` soft/nginx/conf` 存放 nginx 配置文件
- `soft/nginx/log` 存放 nginx 日志文件
- `soft/nginx/www` 存放 nginx 访问的资源文件
- `soft/nginx/ssl` 存放 ssl 证书
   

```fallback
# 启动 nginx
docker run --name nginx -p 80:80 -d --rm nginx
```

导出配置文件

- `docker cp nginx:/etc/nginx/nginx.conf /soft/nginx/conf/nginx.conf` 导出配置文件 nginx.conf
- `docker cp nginx:/etc/nginx/conf.d /soft/nginx/conf/conf.d` 导出配置为你 nginx.conf
   执行`docker stop nginx`，会自动删除现在的 nginx 容器，然后执行如下命令重新启动一个 nginx 容器

```fallback
docker run -d -p 80:80 --name nginx \
-v /soft/nginx/conf/nginx.conf:/etc/nginx/nginx.conf \
-v /soft/nginx/conf/conf.d:/etc/nginx/conf.d \
-v /soft/nginx/www:/usr/share/nginx/html \
-v /soft/nginx/logs:/var/log/nginx nginx
```

- `-v /soft/nginx/conf/nginx.conf:/etc/nginx/nginx.conf \` 挂载配置文件`nginx.conf`
- `-v /soft/nginx/conf/conf.d:/etc/nginx/conf.d` 挂载配置文件`default.conf`
- `-v /soft/nginx/www:/usr/share/nginx/html ` 挂载项目文件
- `-v /soft/nginx/logs:/var/log/nginx` 挂载配置文件
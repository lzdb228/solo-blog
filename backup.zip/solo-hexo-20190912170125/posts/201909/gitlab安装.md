title: gitlab安装
date: '2019-09-12 16:51:11'
updated: '2019-09-12 16:59:47'
tags: [Note]
permalink: /articles/2019/09/12/1568278271466.html
---
![](https://img.hacpai.com/bing/20180619.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 安装准备

```
1.下载wget     
yum install -y wget
2.备份默认的yum
mv /etc/yum.repos.d /etc/yum.repos.d.backup
3.设置新的yum目录
mkdir /etc/yum.repos.d
4.下载阿里yum配置到该目录中
wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
5.重建缓存
yum clean all
yum makecache
6.升级所有包
yum update -y
7.安装vim
yum install -y vim
8.安装gitlab的依赖项
yum install -y curl openssh-server openssh-clients postfix cronie policycoreutils-python
9.启动postfix，并设置为开机启动
systemctl start postfix
systemctl enable postfix
10.设置防火墙 
1）开放所有
firewall-cmd --add-service=http --permanent
firewall-cmd --reload
2）添加指令端口
/sbin/iptables -I INPUT -p tcp --dport 端口号 -j ACCEPT
11.安装git
yum install -y git
```

# 下载汉化包

```
1.下载汉化包
cd /usr/local/src/
git clone https://gitlab.com/xhang/gitlab.git
2.查看该汉化补丁的版本
cat gitlab/VERSION
如图，汉化版本为10.2，所以原版也要下载10.2
```

<img src="C:\Users\zhoudb\AppData\Roaming\Typora\typora-user-images\1568252366966.png" alt="1568252366966" style="zoom: 200%;" />
# 下载原版
查看[清华开源镜像站](https://mirrors.tuna.tsinghua.edu.cn/gitlab-ce/yum/el7/)，下载对应版本的 rpm 包。

<img src="/server/blog/images/1568252523967.png" alt="1568252523967" style="zoom: 150%;" />
```
1.获取rpm包-对应版本
wget https://mirrors.tuna.tsinghua.edu.cn/gitlab-ce/yum/el7/gitlab-ce-10.0.2-ce.0.el7.x86_64.rpm
2.安装rpm包-对应版本
rpm -i gitlab-ce-10.0.2-ce.0.el7.x86_64.rpm
3.修改配置文件gitlab.rb
vim /etc/gitlab/gitlab.rb
将external_url变量的地址修改为gitlab所在centos的ip地址
```
![1568256289474](/server/blog/images/1568256289474.png)

```
gitlab-ctl reconfigure
```

# 汉化

```jsx
1.获取当前Gitlab版本
gitlab_version=$(cat /opt/gitlab/embedded/service/gitlab-rails/VERSION)
2.比较汉化标签和原标签，导出patch用的diff文件
cd /usr/local/src/gitlab
git diff v${gitlab_version} v${gitlab_version}-zh > ../${gitlab_version}-zh.diff
3.导入汉化补丁
patch -d /opt/gitlab/embedded/service/gitlab-rails -p1 < ../${gitlab_version}-zh.diff

PS：如果出现类似以下内容，则按住回车，一直跳过就行了
can't find file to patch at input line 5
Perhaps you used the wrong -p or --strip option?
The text leading up to this was:
--------------------------
|diff --git a/app/assets/javascripts/awards_handler.js b/app/assets/javascripts/awards_handler.js
|index eb0f06e..73e4833 100644
|--- a/app/assets/javascripts/awards_handler.js
|+++ b/app/assets/javascripts/awards_handler.js
--------------------------
File to patch:

4.然后启动gitlab
gitlab-ctl start
```

# 访问页面

打开浏览器，输入前面配置的地址，如果本机可以访问，但其他电脑访问不了，应该是防火墙拦截了端口，可以在

```
防火墙添加端口
/sbin/iptables -I INPUT -p tcp --dport 端口号 -j ACCEPT
如果访问的时候报502错误，加上这句：
chmod -R 755 /var/log/gitlab
```

# 拓展

[GitLab 的基本使用](https://zhuanlan.zhihu.com/p/49819635)

[手把手教你用 Gitlab 和 Jenkins 构建持续集成环境](https://mp.weixin.qq.com/s?src=11&timestamp=1568261468&ver=1847&signature=PNn8HIkmWHdwBAZJt*n1hEeATfKZFhaaoLqos2pwJGvQgDA8cYL4NramKOnQnzRIFpzji83JvTA6Z8Sr*AgruWbB3KlQOYMrH9ahp9SpTx1xs8ZZg5yqZFS73gUDb*a*&new=1)


title: linux初始化
date: '2019-09-12 17:38:10'
updated: '2019-09-12 17:38:10'
tags: [Note]
permalink: /articles/2019/09/12/1568281090508.html
---
# yum换源

```
1.下载wget     
yum install -y wget
2.备份默认的yum
mv /etc/yum.repos.d /etc/yum.repos.d.backup
3.设置新的yum目录
mkdir /etc/yum.repos.d
4.下载阿里yum配置到该目录中
wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
5.重建缓存
yum clean all
yum makecache
6.升级所有包
yum update -y
```



# 安装常用工具

yum install iproute ftp bind-utils net-tools wget vim -y



# 配置镜像加速器

```
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["https://hvmf8r55.mirror.aliyuncs.com"]
}
EOF
sudo systemctl daemon-reload
sudo systemctl restart docker

查看是否生效
tail /etc/docker/daemon.json
```